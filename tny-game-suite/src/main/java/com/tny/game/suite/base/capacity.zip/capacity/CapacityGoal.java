package com.tny.game.suite.base.capacity;

/**
 * 能力值作用者
 * Created by Kun Yang on 16/2/15.
 */
public interface CapacityGoal extends CapacityGather, CapacityObject {
}
