package com.tny.game.suite.base.capacity;

/**
 * 与能力相关的
 * Created by Kun Yang on 16/3/23.
 */
public interface Capacitiable {

}
