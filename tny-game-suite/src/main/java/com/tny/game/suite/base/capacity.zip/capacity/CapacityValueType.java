package com.tny.game.suite.base.capacity;

public enum CapacityValueType {

    BASE,

    INC,

    INC_PCT,

    RED,

    RED_PCT,

    INC_EFF,

    RED_EFF,

}