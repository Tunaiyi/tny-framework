package com.tny.game.suite.base.capacity;

/**
 * Created by Kun Yang on 2017/12/29.
 */
public enum CapacityObjectType {

    GOAL,

    SUPPLIER

}
